
import { useLoaderData } from "react-router-dom";


const ProductPage = ({brand}) => {
    const {brand_name} = brand
    fetch('data.json')
    .then(res=>res.json)
    .then(data=>{
        console.log(data)
    })
    const products = useLoaderData()
    const filtered = products.filter(brands=> brands.brand_name === brand_name)
    console.log(filtered)
        
    return (
        <div>
            <h2>product</h2>
        </div>
    );
};

export default ProductPage;