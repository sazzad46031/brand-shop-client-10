

const Banner = () => {
    return (
        <div>
            <img src="./banner.jpg" alt="" />
            
        </div>
    );
};

export default Banner;